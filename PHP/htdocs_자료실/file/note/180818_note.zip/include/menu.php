<div id="main_head">
	<div id="main_head_in">
		<span id="main_t"><img src="/imgs/logo.png" alt="logo" title="logo" /></span>
		<p id="mem_log"><?php echo $_SESSION['userid']; ?>님 환영합니다.<span id="mlog"><a href="/page/member/logout.php">로그아웃</a></span></p>
	</div>
</div>
